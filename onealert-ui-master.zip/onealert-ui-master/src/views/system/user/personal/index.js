import Personal from './personal'
export default Personal