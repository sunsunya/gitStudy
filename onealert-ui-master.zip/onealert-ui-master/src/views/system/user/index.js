import User from './index.vue'
export default User