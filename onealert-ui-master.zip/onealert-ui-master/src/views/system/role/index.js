import Role from './index.vue'
export default Role