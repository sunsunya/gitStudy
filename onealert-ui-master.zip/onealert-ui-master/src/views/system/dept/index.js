import Dept from './index.vue'
export default Dept