import Position from './index.vue'
export default Position