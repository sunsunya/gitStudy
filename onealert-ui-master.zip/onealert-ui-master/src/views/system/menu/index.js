import Menu from './index.vue'
export default Menu