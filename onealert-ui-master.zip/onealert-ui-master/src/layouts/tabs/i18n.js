module.exports = {
  messages: {
    CN: {
      closeLeft: '关闭左侧',
      closeRight: '关闭右侧',
      closeOthers: '关闭其它',
      warn: '这是最后一页，不能再关闭了',
    },
    US: {
      closeLeft: 'close left',
      closeRight: 'close right',
      closeOthers: 'close others',
      warn: 'This is the last page, you can\'t close it',
    },
  }
}